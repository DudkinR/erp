

 <style>
body {
    background-color: #c0c0c0;
    font-family: Tahoma, Arial, sans-serif;
}

.form-control {
    border: 2px inset #fff;
    background-color: #fff;
    font-size: 14px;
    padding: 2px 4px;
    height: 24px;
}

label {
    font-weight: bold;
    font-size: 13px;
}

.win-card {
    border: 2px outset #fff;
    background-color: #d4d0c8;
    padding: 6px;
    margin-bottom: 8px;
}

.win-header {
    font-weight: bold;
    color: darkblue;
    font-size: 16px;
    margin-bottom: 4px;
    text-align: center;
}

.win-btn {
    border: 2px outset #fff;
    background-color: #e0e0e0;
    padding: 4px 10px;
    font-size: 13px;
    margin: 2px;
    cursor: pointer;
}

.win-btn:active {
    border: 2px inset #fff;
}

/* Кольорові кнопки */
.btn-red {
    background-color: #ffcccc;
    color: darkred;
}

.btn-green {
    background-color: #ccffcc;
    color: darkgreen;
}

.btn-blue {
    background-color: #ccccff;
    color: darkblue;
}
body {
    background-color: #c0c0c0;
    font-family: Tahoma, Arial, sans-serif;
}

.form-control {
    border: 2px inset #fff;
    background-color: #fff;
    font-size: 14px;
    padding: 2px 4px;
    height: 24px;
}

label {
    font-weight: bold;
    font-size: 13px;
}

.win-card {
    border: 2px outset #fff;
    background-color: #d4d0c8;
    padding: 6px;
    margin-bottom: 8px;
}

.win-header {
    font-weight: bold;
    color: darkblue;
    font-size: 16px;
    margin-bottom: 4px;
    text-align: center;
}

.win-btn {
    border: 2px outset #fff;
    background-color: #e0e0e0;
    padding: 4px 10px;
    font-size: 13px;
    margin: 2px;
    cursor: pointer;
}

.win-btn:active {
    border: 2px inset #fff;
}

/* Кольорові кнопки */
.btn-red {
    background-color: #ffcccc;
    color: darkred;
}

.btn-green {
    background-color: #ccffcc;
    color: darkgreen;
}

.btn-blue {
    background-color: #ccccff;
    color: darkblue;
}
</style>
