<div class="form-group mb-2">
    <label for="date_start">{{__('Date start')}}</label>
    <input type="date" class="form-control" id="date_start" name="date_start" value="{{ date('Y-m-d') }}">
</div>