<div class="form-group mb-2  bg-warning">
    <label for="description">{{__('Description')}}</label>
    <textarea class="form-control" id="description" name="description" rows="3"></textarea>
</div>