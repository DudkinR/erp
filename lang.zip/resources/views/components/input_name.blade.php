<div class="form-group mb-2 bg-info">
    <label for="name"><b>{{__('Name')}}</b></label>
    <input type="text" class="form-control" id="name" name="name">
</div>