<div class="form-group mb-2">
    <label for="priority">{{__('Priority')}}</label>
    <input type="number" class="form-control" id="priority" name="priority" value="0" >
</div>