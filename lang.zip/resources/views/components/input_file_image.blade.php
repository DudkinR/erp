<div id="image_preview" class="form-group"></div>
<div class="form-group">
    <label for="image">{{__('Image')}}</label>
    <input type="file" class="form-control" id="image" name="image">
</div>