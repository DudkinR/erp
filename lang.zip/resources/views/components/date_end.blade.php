<div class="form-group mb-2">
    <label for="date_end">{{__('Date end')}}</label>
    <input type="date" class="form-control" id="date_end" name="date_end" >
</div>
