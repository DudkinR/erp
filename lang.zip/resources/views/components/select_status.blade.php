<div class="form-group mb-2">
    <label for="status">{{__('Status')}}</label>
    <select name="status" id="status" class="form-control">
        <option value="new">{{__('New')}}</option>
        <option value="in_progress">{{__('In progress')}}</option>
        <option value="done">{{__('Done')}}</option>
        <option value="closed">{{__('Closed')}}</option>
    </select>
</div>