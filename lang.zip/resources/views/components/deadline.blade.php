<div class="form-group mb-2">
    <label for="deadline">{{__('Deadline')}}</label>
    <input type="date" class="form-control" id="deadline" name="deadline" >
</div>