
// Импортируем Bootstrap
import 'bootstrap';

// Импортируем jQuery
import $ from 'jquery';

// Используем jQuery в глобальной области видимости, чтобы он был доступен во всем приложении
window.jQuery = $;
window.$ = $;


